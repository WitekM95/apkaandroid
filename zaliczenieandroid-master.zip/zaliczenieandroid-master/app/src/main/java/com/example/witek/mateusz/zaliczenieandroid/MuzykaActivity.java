package com.example.witek.mateusz.zaliczenieandroid;

import android.os.Handler;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.media.MediaPlayer;
import android.media.AudioManager;
import android.view.View;
import android.widget.Button;
import android.widget.SeekBar;
import android.widget.TextView;

import java.util.concurrent.TimeUnit;




public class MuzykaActivity extends AppCompatActivity {

    private MediaPlayer mp;
    private SeekBar seekbar;
    private double timeElapsed = 0, finalTime = 10; //czas jaki upłynął, czas finalny
    public TextView audioName, audioDuration;
    private Handler durationHandler = new Handler();


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_muzyka);

        mp = MediaPlayer.create(this,R.raw.sound11);
        seekbar = findViewById(R.id.seekbar1);

        PlayAudioButton(); //metoda obsługująca przycisk Play
        PauseAudioButton(); //metoda obsługująca przycisk Pause
        setVolumeControlStream(AudioManager.STREAM_MUSIC); //sterowanie głośnością przyciskami telefonu
    }

    private void PauseAudioButton() {
        Button bpause = findViewById(R.id.bpause);
        bpause.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                pause(v);
            }
        });


    }

    private void PlayAudioButton() {
        Button bplay = findViewById(R.id.bplay);
        bplay.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                play(v);
            }
        });
    }

    public void play(View view) {
        mp.start();
        timeElapsed = mp.getCurrentPosition();
        seekbar.setProgress((int) timeElapsed);
        durationHandler.postDelayed(updateSeekBarTime, 100);
    }
    public void pause(View view) {
        mp.pause();
    }

    private Runnable updateSeekBarTime = new Runnable() {
        public void run() {
            timeElapsed = mp.getCurrentPosition(); // pobranie aktualnej pozycji utworu
            finalTime = mp.getDuration(); // pobranie czasu trwania utworu
            seekbar.setMax((int) finalTime); //ustawienie maksymalnej wartości paska postępu na długość utworu
            seekbar.setProgress((int) timeElapsed); //ustawnie postępu na aktualną pozycję utworu.
            double timeRemaining = finalTime - timeElapsed;
            audioDuration.setText(String.format("%d min %d sec", // wyświetlenie czasu trwania utworu w formacie min sec
                    TimeUnit.MILLISECONDS.toMinutes((long) timeRemaining),
                    TimeUnit.MILLISECONDS.toSeconds((long) timeRemaining)
                            - TimeUnit.MINUTES.toSeconds(TimeUnit.MILLISECONDS.toMinutes((long)
                            timeRemaining))));
            durationHandler.postDelayed(this, 100);
        }
    };
}
